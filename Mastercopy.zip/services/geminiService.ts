import { Manuscript } from "../types";

// Service disabled by user request
export const generateJMQueryDraft = async (_manuscript: Manuscript, _issueDetail: string): Promise<string> => {
  return "";
};

export const analyzeRisk = async (): Promise<string> => {
  return "";
};