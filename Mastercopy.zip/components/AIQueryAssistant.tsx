import React from 'react';

interface AIQueryAssistantProps {
  manuscript: any;
  onClose: () => void;
}

const AIQueryAssistant: React.FC<AIQueryAssistantProps> = () => {
  return null;
};

export default AIQueryAssistant;